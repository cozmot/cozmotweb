<!doctype html>
<html>
<?php include 'includes/head.php'; ?>
<body>
	<div class="container">
<?php include 'includes/header.php'; ?>