<?php
include 'core/init.php';
protect_page();

if (isset($_GET['username']) === true && empty($_GET['username']) === false) {
	$username 		= $_GET['username'];
	
	if (user_exists($username) === true) {
	$user_id 		= user_id_from_username($username);
	$profile_data 	= user_data($user_id, 'username', 'first_name', 'last_name', 'email', 'profile', 'country', 'phonenumber', 'sex');
	$file_path = $user_data ['profile'];
?><!DOCTYPE html><html class=no-js lang=en><!--<![endif]--><meta charset=UTF-8><title>Gigabyte Developers Incorporated | Profile</title><meta content="width=device-width,initial-scale=1"name=viewport><meta content="Official User Profile Page of Gigabyte Developers Incorporated"name=description><meta content="php, ajax, javascript, jquery, aspx, python, html5, css3, form, switch, animation, :target, pseudo-class"name=keywords><meta content="Gigabyte Developers Incorporated"name=author><meta content=#028fcc name=theme-color><link href=css/demo.css rel=stylesheet><link href=css/style3.css rel=stylesheet><link href=css/animate-custom.css rel=stylesheet><link href=images/gigaicon.ico rel="shortcut icon"><div class=container><header><a href=../index.php><h1>Gigabyte Developers <span>User Profile</span></h1></a></header><section><div id=container_demo><a class=hiddenanchor id=toregister></a> <a class=hiddenanchor id=tologin></a><div id=wrapper><div id=login class="animate form"><?php
	?><h1><?php echo $profile_data['first_name']; ?>'s Profile</h1><p><?php echo '<img class="profile-center", src="../',  $profile_data['profile'], '" alt="">'; ?><p>Username:<?php echo $profile_data['username']; ?><p>Gender:<?php if ($profile_data['sex'] == true) { echo $profile_data['sex']; } else { echo 'Unspecified'; }?><p>Email:<?php echo $profile_data['email']; ?><p>First Name:<?php echo $profile_data['first_name']; ?><p>Last Name:<?php echo $profile_data['last_name']; ?><p>Nationality:<?php if ($profile_data['country'] == true) { echo $profile_data['country']; } else { echo 'None'; }?><p>Phone Number:<?php if ($profile_data['phonenumber'] == true) { echo $profile_data['phonenumber']; } else { echo 'Not Yet Specified'; }?></p><?php
	} else {
		?><!DOCTYPE html><html class=no-js lang=en><!--<![endif]--><meta charset=UTF-8><title>Gigabyte Developers Incorporated | Profile</title><meta content="width=device-width,initial-scale=1"name=viewport><meta content="Official User Profile Page of Gigabyte Developers Incorporated"name=description><meta content="php, ajax, javascript, jquery, aspx, python, html5, css3, form, switch, animation, :target, pseudo-class"name=keywords><meta content="Gigabyte Developers Incorporated"name=author><link href=css/demo.css rel=stylesheet><link href=css/style3.css rel=stylesheet><link href=css/animate-custom.css rel=stylesheet><link href=images/gigaicon.ico rel="shortcut icon"><div class=container><header><a href=../index.php><h1>Gigabyte Developers Incorporated</h1></a></header><section><div id=container_demo><a class=hiddenanchor id=toregister></a> <a class=hiddenanchor id=tologin></a><div id=wrapper><div id=login class="animate form"><?php
?><h1><?php echo 'Dead End!';?></h1><p class=textmode>Sorry, this user (<b>"<?php echo $_GET['username'] ?>"</b>) isn't registered on our database. Please try again!<p class=textmode>If this problem persists and you are very sure of what you are doing, then head straight to contact our hotline by calling +2348104309369, or email: <a href=mailto:nwokomaemmanuel@gmail.com>Administrator</a>.</p><?php
	}
}
 
include 'includes/overall/overallfooter.php'; ?>