<?php
include 'core/init.php';
// CHECK
logged_in_redirect();
?>
<!DOCTYPE html>
<html lang="en" class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="UTF-8" />
        <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  -->
        <title>Gigabyte Developers | Username Recovery</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <meta name="description" content="Official Username Recovery Page of Gigabyte Developers Incorporated" />
        <meta name="keywords" content="php, ajax, javascript, jquery, aspx, python, html5, css3, form, switch, animation, :target, pseudo-class" />
        <meta name="author" content="Gigabyte Developers Incorporated" />
        <meta name="theme-color" content="#028fcc">
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style3.css" />
		<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
		<link rel="shortcut icon" href="images/gigaicon.ico">
    </head>
    <body>
        <div class="container">
            <header>
                <a href="index"><h1>Gigabyte Developers <span>Account Recovery Assistant</h1></a>
            </header>
            <section>				
                <div id="container_demo" >
                    <a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
<?php
?>
<h1>Username Recovery</h1>
<?php
if (isset($_GET['success']) === true && empty($_GET['success']) === true) {
?>
	<p class="textmode">Thank's we've sent your username to your mailbox.</p>
<?php
} else {
	$mode_allowed = array('username');
	if (isset($_GET['mode']) === true && in_array($_GET['mode'], $mode_allowed) === true) {
		if (isset($_POST['email']) === true && empty($_POST['email']) === false) {
			if (email_exists($_POST['email']) === true) {
				recover($_GET['mode'], $_POST['email']);
				echo '<meta http-equiv="refresh" content="0; URL=recover?success">';
				exit();
			} else {
				echo '<p>Oops, we could\'t find that email address</p>';
			}
		}
	?>
		<form action="" method="post">
					<p> 
                        <label for="email" class="email" data-icon="e" > Please enter your registered email address </label>
                        <input id="email" name="email" required="required" type="text" placeholder="Email Address"/>
                    </p>
				</li>
				<p class="recover buttons"> 
                    <input type="submit" value="Recover" /> 
				</p>
			</form>
	<?php
	} else {
		header('Location: loggedin');
		exit();
	}
}
?>